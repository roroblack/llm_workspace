# v3_commerce — 쇼핑몰 실습 잔재

보험 도메인 전환(2026-08) 시점에 쓰이지 않게 된 것들.

## 옮긴 것

| 경로 | 원래 자리 | 무엇 |
|---|---|---|
| `app/routers/` | `app/routers/` | products · orders · payments |
| `app/tools/commerce_tools.py` | 〃 | 커머스 에이전트 도구(185줄) |
| `app/application/commerce.py` | 〃 | 커머스 유스케이스 |
| `app/adapters/` | 〃 | sql_order_repo · sql_catalog |
| `app/services/` | 〃 | payment · order · catalog · admin_report |
| `app/schemas/commerce.py` | 〃 | 커머스 DTO |
| `app/ml/recommend.py` | 〃 | 상품 추천 |
| `app/a2a/` | 〃 | **이름만 A2A인 커머스 잔재**. 표준 A2A 가 아니다 |
| `static/` | `app/static/` | shop · orders · index · mcp 화면 |
| `data/` | `data/` | mall.db · products.csv · orders.csv · inventory.csv · cs_inquiries.csv |

## 주의

`app/db/models.py` 와 `app/db/seed.py` 는 **옮기지 않았다.**
커머스 테이블이 들어 있지만 인증·감사 등 현행 코드가 같은 파일을 쓴다.
분리는 백엔드 담당이 DB 스키마를 새로 짤 때 함께 한다.
